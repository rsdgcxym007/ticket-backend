import { Injectable } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Auth } from './auth.entity';
import { LoginDto } from './dto/login.dto';
import * as bcrypt from 'bcrypt';
import { RegisterDto } from './dto/register.dto';
import { User } from '../user/user.entity';
import { Staff } from '../staff/staff.entity';
import { SessionService } from './session.service';
import {
  LoggingHelper,
  ErrorHandlingHelper,
  AuditHelper,
} from '../common/utils';
import { AuditAction } from '../common/enums';
@Injectable()
export class AuthService {
  constructor(
    private jwtService: JwtService,
    @InjectRepository(Auth)
    private readonly authRepo: Repository<Auth>,
    @InjectRepository(User)
    private readonly userRepo: Repository<User>,
    @InjectRepository(Staff)
    private readonly staffRepo: Repository<Staff>,
    private readonly sessionService: SessionService,
  ) {}

  async login(
    dto: LoginDto,
    deviceInfo?: string,
    ipAddress?: string,
    userAgent?: string,
  ): Promise<{ access_token: string; user: any; staff?: any }> {
    const logger = LoggingHelper.createContextLogger('AuthService');
    const startTime = Date.now();

    return ErrorHandlingHelper.retry(async () => {
      const auth = await this.authRepo.findOne({
        where: { email: dto.email },
        relations: ['user'],
      });

      if (!auth) {
        throw ErrorHandlingHelper.createError(
          'ไม่พบอีเมลนี้ในระบบ',
          401,
          'AUTH_USER_NOT_FOUND',
        );
      }

      const isPasswordValid = await bcrypt.compare(dto.password, auth.password);
      if (!isPasswordValid) {
        throw ErrorHandlingHelper.createError(
          'รหัสผ่านไม่ถูกต้อง',
          401,
          'AUTH_INVALID_PASSWORD',
        );
      }

      if (!auth.user) {
        throw ErrorHandlingHelper.createError(
          'ไม่พบข้อมูลผู้ใช้ที่เชื่อมกับบัญชีนี้',
          404,
          'AUTH_USER_DATA_NOT_FOUND',
        );
      }

      // ตรวจสอบว่ามีข้อมูล Staff หรือไม่
      const staff = await this.staffRepo.findOne({
        where: { email: dto.email },
      });

      // สร้าง session ใหม่ (จะปิด sessions เก่าทั้งหมดอัตโนมัติ)
      const { access_token } = await this.sessionService.createSession(
        auth.user.id,
        deviceInfo,
        ipAddress,
        userAgent,
      );

      // eslint-disable-next-line @typescript-eslint/no-unused-vars
      const { password: _, ...safeUser } = auth;

      // 📝 Audit logging for login
      await AuditHelper.log({
        action: AuditAction.LOGIN,
        entityType: 'Auth',
        entityId: auth.user.id,
        context: AuditHelper.createSystemContext({
          source: 'AuthService.login',
          email: dto.email,
          loginTime: new Date().toISOString(),
          hasStaffProfile: !!staff,
          deviceInfo,
          ipAddress,
        }),
      });

      LoggingHelper.logBusinessEvent(logger, 'User login successful', {
        userId: auth.user.id,
        email: dto.email,
        hasStaffProfile: !!staff,
      });

      LoggingHelper.logPerformance(logger, 'auth.login', startTime, {
        userId: auth.user.id,
      });

      const result: any = {
        access_token,
        user: safeUser,
      };

      if (staff) {
        result.staff = {
          id: staff.id,
          staffCode: staff.staffCode,
          fullName: staff.fullName,
          role: staff.role,
          status: staff.status,
          permissions: staff.permissions,
          department: staff.department,
          position: staff.position,
        };
      }

      return result;
    }, 2);
  }

  /**
   * Logout - ปิด session ปัจจุบัน
   */
  async logout(tokenId: string): Promise<void> {
    const logger = LoggingHelper.createContextLogger('AuthService');

    await this.sessionService.revokeSessionByTokenId(tokenId);

    LoggingHelper.logBusinessEvent(logger, 'User logout successful', {
      tokenId,
    });

    // 📝 Audit logging for logout
    await AuditHelper.log({
      action: AuditAction.LOGOUT,
      entityType: 'Auth',
      entityId: tokenId,
      context: AuditHelper.createSystemContext({
        source: 'AuthService.logout',
        logoutTime: new Date().toISOString(),
      }),
    });
  }

  /**
   * Logout from all devices - ปิด sessions ทั้งหมด
   */
  async logoutAll(userId: string): Promise<void> {
    const logger = LoggingHelper.createContextLogger('AuthService');

    await this.sessionService.revokeAllUserSessions(userId);

    LoggingHelper.logBusinessEvent(logger, 'User logout all successful', {
      userId,
    });

    // 📝 Audit logging for logout all
    await AuditHelper.log({
      action: AuditAction.LOGOUT,
      entityType: 'Auth',
      entityId: userId,
      context: AuditHelper.createSystemContext({
        source: 'AuthService.logoutAll',
        logoutTime: new Date().toISOString(),
        type: 'all_devices',
      }),
    });
  }

  async changePasswordByEmail(
    email: string,
    oldPassword: string,
    newPassword: string,
  ): Promise<void> {
    const auth = await this.authRepo.findOne({ where: { email } });
    if (!auth) {
      throw ErrorHandlingHelper.createError(
        'User not found',
        404,
        'USER_NOT_FOUND',
      );
    }
    if (!auth.password) {
      throw ErrorHandlingHelper.createError(
        'No password set',
        400,
        'NO_PASSWORD',
      );
    }
    const isMatch = await bcrypt.compare(oldPassword, auth.password);
    if (!isMatch) {
      throw ErrorHandlingHelper.createError(
        'Old password incorrect',
        400,
        'INVALID_OLD_PASSWORD',
      );
    }
    const hashed = await bcrypt.hash(newPassword, 12);
    auth.password = hashed;
    await this.authRepo.save(auth);
  }
  async socialLogin(profile: any): Promise<string> {
    const { id, provider, emails, displayName, photos } = profile;
    const email = emails?.[0]?.value || '';
    const avatar = photos?.[0]?.value || '';

    let auth = await this.authRepo.findOne({
      where: { providerId: id, provider },
    });

    if (!auth) {
      // สร้าง User record ก่อน
      const newUser = this.userRepo.create({
        email,
        name: displayName,
        role: 'user',
      });
      const savedUser = await this.userRepo.save(newUser);

      // จากนั้นสร้าง Auth record พร้อม userId
      auth = this.authRepo.create({
        providerId: id,
        provider,
        email,
        displayName,
        avatar,
        userId: savedUser.id, // เพิ่ม userId
      });
      await this.authRepo.save(auth);
    }

    const payload = { sub: auth.id, role: auth.role };
    return this.jwtService.sign(payload);
  }

  async getUserById(id: string): Promise<Auth> {
    return this.authRepo.findOne({ where: { id } });
  }

  async register(
    dto: RegisterDto,
  ): Promise<{ access_token: string; user: any }> {
    const logger = LoggingHelper.createContextLogger('AuthService');
    const startTime = Date.now();

    return ErrorHandlingHelper.retry(async () => {
      const email = dto.email.toLowerCase().trim();

      const existing = await this.authRepo.findOne({ where: { email } });
      if (existing) {
        throw ErrorHandlingHelper.createError(
          'Email already in use',
          409,
          'EMAIL_ALREADY_EXISTS',
        );
      }

      const newUser = this.userRepo.create({
        email,
        name: dto.name,
        role: dto.role || 'user',
      });
      const savedUser = await this.userRepo.save(newUser);

      const hashed = await bcrypt.hash(dto.password, 10);
      const auth = this.authRepo.create({
        email: savedUser.email,
        password: hashed,
        displayName: savedUser.name,
        provider: 'manual',
        providerId: savedUser.id,
        userId: savedUser.id, // เพิ่ม userId ที่ถูกต้อง
        role: savedUser.role,
      });
      await this.authRepo.save(auth);

      const payload = { sub: auth.id, email: auth.email, role: auth.role };
      const access_token = this.jwtService.sign(payload);

      // eslint-disable-next-line @typescript-eslint/no-unused-vars
      const { password: _, ...safeUser } = auth;

      // 📝 Audit logging for registration
      await AuditHelper.logCreate(
        'Auth',
        auth.id,
        { email: dto.email, role: auth.role },
        AuditHelper.createSystemContext({
          source: 'AuthService.register',
          registrationTime: new Date().toISOString(),
        }),
      );

      LoggingHelper.logBusinessEvent(logger, 'User registration successful', {
        userId: auth.id,
        email: dto.email,
      });

      LoggingHelper.logPerformance(logger, 'auth.register', startTime, {
        userId: auth.id,
      });

      return { access_token, user: safeUser };
    }, 2);
  }
}
