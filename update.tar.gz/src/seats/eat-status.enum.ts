export enum SeatStatus {
  AVAILABLE = 'AVAILABLE',
  LOCKED = 'LOCKED',
  BOOKED = 'BOOKED',
  PAID = 'PAID',
  EMPTY = 'EMPTY',
}
